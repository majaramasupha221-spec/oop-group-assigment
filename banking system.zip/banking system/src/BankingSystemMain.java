import banking.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BankingSystemMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Polymorphism: Using BankAccount superclass references to hold SavingsAccount and CurrentAccount objects
        ArrayList<BankAccount> accounts = new ArrayList<>();

        // Initialize sample accounts
        try {
            accounts.add(new SavingsAccount("SAV-101", "Majara Masupha", 1500.00));
            accounts.add(new CurrentAccount("CUR-201", "Lepoqo Masupha", 500.00));
        } catch (InvalidTransactionException e) {
            System.out.println("Initialization error: " + e.getMessage());
        }

        int choice = 0;
        do {
            System.out.println("\n========================================");
            System.out.println("       CONSOLE BANKING SYSTEM MENU      ");
            System.out.println("========================================");
            System.out.println("1. Display all accounts");
            System.out.println("2. Deposit money");
            System.out.println("3. Withdraw money");
            System.out.println("4. Transfer money");
            System.out.println("5. Calculate interest");
            System.out.println("6. Request bank loan");
            System.out.println("7. Display account details");
            System.out.println("8. Exit");
            System.out.print("Enter your choice (1-8): ");

            try {
                if (!scanner.hasNextInt()) {
                    System.out.println("Error: Invalid numeric input. Please enter a number between 1 and 8.");
                    scanner.next(); // consume invalid token
                    continue;
                }
                choice = scanner.nextInt();
                scanner.nextLine(); // consume newline

                switch (choice) {
                    case 1:
                        System.out.println("\n--- All Bank Accounts ---");
                        for (BankAccount acc : accounts) {
                            // Polymorphic call to overridden displayAccountInfo()
                            acc.displayAccountInfo();
                            System.out.println();
                        }
                        break;

                    case 2:
                        System.out.print("Enter Account Number: ");
                        String depAccNum = scanner.nextLine();
                        BankAccount depAcc = findAccount(accounts, depAccNum);
                        if (depAcc != null) {
                            System.out.print("Enter deposit amount (M): ");
                            double depAmount = scanner.nextDouble();
                            scanner.nextLine();
                            depAcc.deposit(depAmount); // Polymorphic deposit
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;

                    case 3:
                        System.out.print("Enter Account Number: ");
                        String witAccNum = scanner.nextLine();
                        BankAccount witAcc = findAccount(accounts, witAccNum);
                        if (witAcc != null) {
                            System.out.print("Enter withdrawal amount (M): ");
                            double witAmount = scanner.nextDouble();
                            scanner.nextLine();
                            witAcc.withdraw(witAmount); // Polymorphic withdraw
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;

                    case 4:
                        System.out.print("Enter Source Account Number: ");
                        String srcNum = scanner.nextLine();
                        BankAccount srcAcc = findAccount(accounts, srcNum);
                        if (srcAcc == null) {
                            System.out.println("Source account not found.");
                            break;
                        }

                        System.out.print("Enter Destination Account Number: ");
                        String destNum = scanner.nextLine();
                        BankAccount destAcc = findAccount(accounts, destNum);
                        if (destAcc == null) {
                            System.out.println("Destination account not found.");
                            break;
                        }

                        System.out.print("Enter transfer amount (M): ");
                        double transAmount = scanner.nextDouble();
                        scanner.nextLine();

                        if (transAmount <= 0) {
                            System.out.println("Transfer amount must be positive.");
                            break;
                        }

                        try {
                            srcAcc.withdraw(transAmount);
                            destAcc.deposit(transAmount);
                            TransactionLogger.logTransaction(srcAcc.getAccountNumber(), "TRANSFER-OUT", transAmount, srcAcc.getBalance(), "SUCCESS to " + destAcc.getAccountNumber());
                            TransactionLogger.logTransaction(destAcc.getAccountNumber(), "TRANSFER-IN", transAmount, destAcc.getBalance(), "SUCCESS from " + srcAcc.getAccountNumber());
                            System.out.printf("Successfully transferred M%.2f from %s to %s\n", transAmount, srcNum, destNum);
                        } catch (InsufficientFundsException | InvalidTransactionException e) {
                            System.out.println("Transfer failed: " + e.getMessage());
                            TransactionLogger.logTransaction(srcAcc.getAccountNumber(), "TRANSFER", transAmount, srcAcc.getBalance(), "FAILED: " + e.getMessage());
                        }
                        break;

                    case 5:
                        System.out.print("Enter Account Number for Interest Calculation: ");
                        String intAccNum = scanner.nextLine();
                        BankAccount intAcc = findAccount(accounts, intAccNum);
                        if (intAcc != null) {
                            intAcc.calculateInterest(); // Polymorphic interest calculation
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;

                    case 6:
                        System.out.print("Enter Account Number for Loan Request: ");
                        String loanAccNum = scanner.nextLine();
                        BankAccount loanAcc = findAccount(accounts, loanAccNum);
                        if (loanAcc != null) {
                            if (loanAcc instanceof Loanable) {
                                System.out.print("Enter loan amount requested (M): ");
                                double loanAmount = scanner.nextDouble();
                                scanner.nextLine();
                                ((Loanable) loanAcc).requestLoan(loanAmount);
                            } else {
                                System.out.println("This account type does not support loans.");
                            }
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;

                    case 7:
                        System.out.print("Enter Account Number to Display Details: ");
                        String detAccNum = scanner.nextLine();
                        BankAccount detAcc = findAccount(accounts, detAccNum);
                        if (detAcc != null) {
                            detAcc.displayAccountInfo();
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;

                    case 8:
                        System.out.println("Exiting Console Banking System. Thank you for banking with us!");
                        break;

                    default:
                        System.out.println("Invalid menu choice! Please choose between 1 and 8.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Invalid numeric input format.");
                scanner.nextLine(); // clear scanner buffer
            } catch (InsufficientFundsException | InvalidTransactionException e) {
                System.out.println("Transaction Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }

        } while (choice != 8);

        scanner.close();
    }

    private static BankAccount findAccount(ArrayList<BankAccount> accounts, String accountNumber) {
        for (BankAccount acc : accounts) {
            if (acc.getAccountNumber().equalsIgnoreCase(accountNumber)) {
                return acc;
            }
        }
        return null;
    }
}