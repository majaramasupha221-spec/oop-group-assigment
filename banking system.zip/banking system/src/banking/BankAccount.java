package banking;

public abstract class BankAccount {
    // Encapsulation: private fields
    private String accountNumber;
    private String accountHolder;
    private double balance;

    public BankAccount(String accountNumber, String accountHolder, double initialBalance) throws InvalidTransactionException {
        if (initialBalance < 0) {
            throw new InvalidTransactionException("Opening balance must not be negative.");
        }
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = initialBalance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    public double getBalance() {
        return balance;
    }

    protected void setBalance(double balance) {
        this.balance = balance;
    }

    // Abstract methods for polymorphism and overriding
    public abstract void deposit(double amount) throws InvalidTransactionException;

    public abstract void withdraw(double amount) throws InsufficientFundsException, InvalidTransactionException;

    public abstract void calculateInterest();

    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder: " + accountHolder);
        System.out.printf("Balance: M%.2f\n", balance);
    }
}