package banking;

public class CurrentAccount extends BankAccount implements Loanable {
    private static final double OVERDRAFT_LIMIT = 2000.00;
    private static final double MAX_LOAN_LIMIT = 15000.00;

    public CurrentAccount(String accountNumber, String accountHolder, double initialBalance) throws InvalidTransactionException {
        super(accountNumber, accountHolder, initialBalance);
    }

    @Override
    public void deposit(double amount) throws InvalidTransactionException {
        if (amount <= 0) {
            TransactionLogger.logTransaction(getAccountNumber(), "DEPOSIT", amount, getBalance(), "FAILED: Amount must be greater than zero");
            throw new InvalidTransactionException("Deposit amount must be greater than zero.");
        }
        setBalance(getBalance() + amount);
        TransactionLogger.logTransaction(getAccountNumber(), "DEPOSIT", amount, getBalance(), "SUCCESS");
        System.out.printf("Successfully deposited M%.2f into Current Account. New Balance: M%.2f\n", amount, getBalance());
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException, InvalidTransactionException {
        if (amount <= 0) {
            TransactionLogger.logTransaction(getAccountNumber(), "WITHDRAW", amount, getBalance(), "FAILED: Withdrawal amount must be greater than zero");
            throw new InvalidTransactionException("Withdrawal amount must be greater than zero.");
        }
        double availableFunds = getBalance() + OVERDRAFT_LIMIT;
        if (amount > availableFunds) {
            TransactionLogger.logTransaction(getAccountNumber(), "WITHDRAW", amount, getBalance(), "FAILED: Exceeds available funds including M2,000.00 overdraft");
            throw new InsufficientFundsException("Withdrawal failed. Exceeds balance and M2,000.00 overdraft limit.");
        }
        setBalance(getBalance() - amount);
        TransactionLogger.logTransaction(getAccountNumber(), "WITHDRAW", amount, getBalance(), "SUCCESS");
        System.out.printf("Successfully withdrew M%.2f from Current Account. New Balance: M%.2f\n", amount, getBalance());
    }

    @Override
    public void calculateInterest() {
        TransactionLogger.logMessage(getAccountNumber(), "INTEREST", "Current accounts earn no interest.");
        System.out.println("Current Accounts do not earn interest.");
    }

    @Override
    public void requestLoan(double amount) throws InvalidTransactionException {
        if (amount <= 0) {
            TransactionLogger.logTransaction(getAccountNumber(), "LOAN", amount, getBalance(), "FAILED: Loan request must be positive");
            throw new InvalidTransactionException("Loan request amount must be greater than zero.");
        }
        if (amount > MAX_LOAN_LIMIT) {
            TransactionLogger.logTransaction(getAccountNumber(), "LOAN", amount, getBalance(), "FAILED: Exceeds maximum loan limit of M15,000.00");
            throw new InvalidTransactionException("Loan request exceeds permitted loan limit of M15,000.00 for Current Account.");
        }
        setBalance(getBalance() + amount);
        TransactionLogger.logTransaction(getAccountNumber(), "LOAN", amount, getBalance(), "SUCCESS");
        System.out.printf("Loan of M%.2f approved and added to Current Account. New Balance: M%.2f\n", amount, getBalance());
    }

    @Override
    public void displayAccountInfo() {
        System.out.println("--- Current Account Details ---");
        super.displayAccountInfo();
        System.out.println("Account Type: Current");
        System.out.println("Overdraft Limit: M2,000.00");
        System.out.println("-----------------------------");
    }
}