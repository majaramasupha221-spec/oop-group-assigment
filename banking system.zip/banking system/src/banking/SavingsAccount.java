package banking;

public class SavingsAccount extends BankAccount implements Loanable {
    private static final double MIN_BALANCE = 100.00;
    private static final double INTEREST_RATE = 0.05; // 5% annual interest
    private static final double MAX_LOAN_LIMIT = 5000.00;

    public SavingsAccount(String accountNumber, String accountHolder, double initialBalance) throws InvalidTransactionException {
        super(accountNumber, accountHolder, initialBalance);
    }

    @Override
    public void deposit(double amount) throws InvalidTransactionException {
        if (amount <= 0) {
            TransactionLogger.logTransaction(getAccountNumber(), "DEPOSIT", amount, getBalance(), "FAILED: Amount must be greater than zero");
            throw new InvalidTransactionException("Deposit amount must be greater than zero.");
        }
        setBalance(getBalance() + amount);
        TransactionLogger.logTransaction(getAccountNumber(), "DEPOSIT", amount, getBalance(), "SUCCESS");
        System.out.printf("Successfully deposited M%.2f into Savings Account. New Balance: M%.2f\n", amount, getBalance());
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException, InvalidTransactionException {
        if (amount <= 0) {
            TransactionLogger.logTransaction(getAccountNumber(), "WITHDRAW", amount, getBalance(), "FAILED: Withdrawal amount must be greater than zero");
            throw new InvalidTransactionException("Withdrawal amount must be greater than zero.");
        }
        if ((getBalance() - amount) < MIN_BALANCE) {
            TransactionLogger.logTransaction(getAccountNumber(), "WITHDRAW", amount, getBalance(), "FAILED: Violates minimum balance of M100.00");
            throw new InsufficientFundsException("Withdrawal failed. Savings account must maintain a minimum balance of M100.00.");
        }
        setBalance(getBalance() - amount);
        TransactionLogger.logTransaction(getAccountNumber(), "WITHDRAW", amount, getBalance(), "SUCCESS");
        System.out.printf("Successfully withdrew M%.2f from Savings Account. New Balance: M%.2f\n", amount, getBalance());
    }

    @Override
    public void calculateInterest() {
        double interest = getBalance() * INTEREST_RATE;
        setBalance(getBalance() + interest);
        TransactionLogger.logTransaction(getAccountNumber(), "INTEREST", interest, getBalance(), "SUCCESS");
        System.out.printf("Calculated and added 5%% interest (M%.2f) to Savings Account. New Balance: M%.2f\n", interest, getBalance());
    }

    @Override
    public void requestLoan(double amount) throws InvalidTransactionException {
        if (amount <= 0) {
            TransactionLogger.logTransaction(getAccountNumber(), "LOAN", amount, getBalance(), "FAILED: Loan request must be positive");
            throw new InvalidTransactionException("Loan request amount must be greater than zero.");
        }
        if (amount > MAX_LOAN_LIMIT) {
            TransactionLogger.logTransaction(getAccountNumber(), "LOAN", amount, getBalance(), "FAILED: Exceeds maximum loan limit of M5,000.00");
            throw new InvalidTransactionException("Loan request exceeds permitted loan limit of M5,000.00 for Savings Account.");
        }
        setBalance(getBalance() + amount);
        TransactionLogger.logTransaction(getAccountNumber(), "LOAN", amount, getBalance(), "SUCCESS");
        System.out.printf("Loan of M%.2f approved and added to Savings Account. New Balance: M%.2f\n", amount, getBalance());
    }

    @Override
    public void displayAccountInfo() {
        System.out.println("--- Savings Account Details ---");
        super.displayAccountInfo();
        System.out.println("Account Type: Savings");
        System.out.println("Interest Rate: 5%");
        System.out.println("Minimum Balance Required: M100.00");
        System.out.println("-----------------------------");
    }
}