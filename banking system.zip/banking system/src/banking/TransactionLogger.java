package banking;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class TransactionLogger {
    private static final String FILE_NAME = "transactions.txt";

    public static void logTransaction(String accountNumber, String transactionType, double amount, double balance, String result) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String timestamp = dtf.format(LocalDateTime.now());

        String logEntry = String.format("[%s] | Acc: %s | Type: %s | Amount: M%.2f | Balance: M%.2f | Result: %s",
                timestamp, accountNumber, transactionType, amount, balance, result);

        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME, true))) {
            out.println(logEntry);
        } catch (IOException e) {
            System.err.println("Error writing to transaction log file: " + e.getMessage());
        }
    }

    public static void logMessage(String accountNumber, String transactionType, String result) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String timestamp = dtf.format(LocalDateTime.now());

        String logEntry = String.format("[%s] | Acc: %s | Type: %s | Result: %s",
                timestamp, accountNumber, transactionType, result);

        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME, true))) {
            out.println(logEntry);
        } catch (IOException e) {
            System.err.println("Error writing to transaction log file: " + e.getMessage());
        }
    }
}